/**
 * This package is our solution to the Google Hashcode qualification of 2021.
 */
package hashcode;
