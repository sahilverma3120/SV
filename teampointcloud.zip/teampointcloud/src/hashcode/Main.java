package hashcode;

public class Main {

    /**
     * The main driver of the project.
     * @param args standard arguments
     */
    public static void main(final String[] args) {
        /*
        System.out.println("Hello");
        FileManager.createFile("testFile.txt");
        FileManager.clearFile("testFile.txt");
        FileManager.writeIntoFile("testFile.txt", "Test line 1");
        FileManager.readFile("testFile.txt");
        FileManager.writeIntoFile("testFile.txt", "Test line 2");
        FileManager.writeIntoFile("testFile.txt", "Test line 3");
        FileManager.readFile("testFile.txt");
        */
        ReadInputFile.getInputFromFile("a.txt");
        Submission.submit(7);
    }
}
